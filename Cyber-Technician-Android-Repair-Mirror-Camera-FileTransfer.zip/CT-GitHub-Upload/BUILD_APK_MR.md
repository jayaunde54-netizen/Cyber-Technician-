# Cyber Technician – Android APK Build (मराठी)

## या पॅकेजमध्ये
- Android launcher: `app/src/main/java/com/cybertechnician/app/MainActivity.java`
- Chaquopy Python backend: `app/src/main/python/`
- Android Gradle module: `app/build.gradle`
- GitHub Actions workflow: `.github/workflows/android.yml`

## GitHub Actions मधून APK तयार करणे
1. हा संपूर्ण प्रोजेक्ट GitHub repository मध्ये upload करा.
2. Repository च्या default branch चे नाव `main` ठेवा (किंवा workflow मधील branch बदला).
3. GitHub मध्ये **Actions** tab उघडा.
4. **Build Cyber Technician APK** workflow निवडा.
5. **Run workflow** दाबा.
6. Build पूर्ण झाल्यावर workflow run मधील **Artifacts** विभागातून `Cyber-Technician-debug-APK` डाउनलोड करा.
7. ZIP extract केल्यावर `app-debug.apk` मिळेल.

## Termux मधून build
Android SDK, Java 17 आणि Gradle 8.13 उपलब्ध असलेल्या वातावरणात:
```bash
chmod +x ./gradlew
./gradlew :app:assembleDebug --no-daemon
```
APK output:
`app/build/outputs/apk/debug/app-debug.apk`

## महत्त्वाच्या मर्यादा
- हा workflow **debug APK** तयार करतो; Play Store/release साठी signed release build वेगळा करावा लागेल.
- या पॅकेजला या चालू वातावरणात प्रत्यक्ष APK build करून तपासता आलेला नाही. Gradle distribution download करण्यासाठी नेटवर्क/DNS उपलब्ध नव्हते आणि Android SDK स्थानिकरीत्या उपलब्ध नव्हता.
- APK तयार झाल्यानंतर प्रत्यक्ष Android फोनवर install, first-run license activation, login, bill generation, QR payment आणि offline behavior तपासा.
- स्वतःच्या GitHub repository मध्ये source upload करताना secrets/passwords किंवा ग्राहकांची खरी माहिती commit करू नका.
