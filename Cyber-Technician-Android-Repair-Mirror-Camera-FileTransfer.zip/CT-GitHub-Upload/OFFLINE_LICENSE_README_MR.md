# CyberTechnician – Offline QR / License Key Activation

## काय जोडले आहे
- Developer, Admin आणि Staff साठी स्वतंत्र signed role license.
- License मध्ये विशिष्ट Android installation चा Device ID, Role आणि वैधता असते.
- QR Code आणि License Key मध्ये एकच signed token असतो.
- APK मध्ये फक्त RSA-3072 public key आहे. Private signing key APK किंवा source ZIP मध्ये नाही.
- प्रत्येक request वेळी signed license पुन्हा तपासला जातो; `settings.json` मधील Role बदलून Developer होणे पुरेसे ठरत नाही.
- जुन्या shop settings, bill records आणि service workflow फाइल्स तशाच ठेवल्या आहेत. जुन्या plaintext password fields PBKDF2 salted password hash मध्ये migrate होतात.

## Offline activation
1. APK उघडा. Activation पानावर Device ID दिसेल.
2. तो Device ID Developer कडे द्या.
3. Developer संगणकावर OpenSSL असताना खालील command चालवेल:

```bash
python tools/license/generate_license.py --private-key /secure/path/CyberTechnician-License-Private.pem --device-id DEVICE_ID_HERE --role developer --out developer-license
```

Admin किंवा Staff साठी `--role admin` किंवा `--role staff` वापरा.
4. तयार होणारी `.key.txt` फाईलमधील token कॉपी करा किंवा `.png` QR image स्कॅन करून त्यातील मजकूर घ्या.
5. APK च्या Activation स्क्रीनवर token पेस्ट करून Activate करा. त्यानंतर त्या role साठी पासवर्ड सेट करा.

`--days 365` वापरल्यास 365 दिवसांचा expiry जोडता येतो. `--days` न दिल्यास expiry नसतो. पूर्ण offline वापरासाठी no-expiry license सोपा आहे.

## अत्यंत महत्त्वाची Key सुरक्षा
- `CyberTechnician-License-Private.pem` ही private signing key स्वतंत्रपणे सुरक्षित ठेवा; ती APK, ZIP, WhatsApp किंवा Admin/Staff कडे देऊ नका.
- हरवली किंवा इतरांकडे गेली तर त्या key ने बनवलेले licenses विश्वासार्ह राहणार नाहीत; नवीन keypair आणि app update आवश्यक होईल.
- QR image मध्ये password नसतो; त्यात फक्त signed license token असतो.

## सध्याच्या टप्प्याच्या मर्यादा
- हा टप्पा offline signed activation, device binding आणि role-based login जोडतो. Android Gradle build येथे पूर्ण करता आलेला नाही कारण Gradle distribution download साठी network उपलब्ध नव्हते.
- QR scan सध्या स्वतंत्र offline QR scanner ने करून token पेस्ट करण्याच्या स्वरूपात आहे; APK मधील native camera scanner अजून जोडलेला नाही.
- Developer private key नसल्यामुळे Admin स्वतः नवीन Staff licenses cryptographically sign करू शकत नाही. Admin staff account/permissions manage करण्यासाठी पुढील टप्प्यात Developer-signed delegated signing capability जोडावी लागेल.
- Offline app मधील स्थानिक data किंवा APK वर device मालकाचा पूर्ण ताबा असतो. त्यामुळे rooted/tampered device विरुद्ध 100% tamper-proof enforcement शक्य नाही. Signed license हा role forgery रोखण्यासाठी मजबूत उपाय आहे, पण संपूर्ण device security ची हमी नाही.
- Expiry तपासणी device clock वर अवलंबून असल्याने offline वापरात clock मागे नेण्याचा धोका असतो. कायमस्वरूपी offline license साठी expiry न ठेवणे अधिक सुसंगत आहे.

## तपासणी
- Python syntax compilation: PASS
- RSA signature verification: PASS
- Device ID mismatch rejection: PASS
- Token tampering rejection: PASS
- Android APK build: NOT RUN TO COMPLETION (Gradle distribution download failed: no network)
