import os
import secrets
import threading
from pathlib import Path

home = Path(os.environ["HOME"])
os.chdir(home)

key_file = home / "secret.key"
if not key_file.exists():
    key_file.write_text(secrets.token_hex(32), encoding="utf-8")

from app import app

def start_server():
    app.run(
        host="127.0.0.1",
        port=5000,
        debug=False,
        use_reloader=False
    )

def start():
    thread = threading.Thread(target=start_server, daemon=True)
    thread.start()

start()
