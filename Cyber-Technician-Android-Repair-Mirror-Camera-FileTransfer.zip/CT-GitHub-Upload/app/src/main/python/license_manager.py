"""Offline RSA-signed role licenses. Private signing key is never bundled in the APK."""
import base64
import datetime
import hashlib
import json
import os
import secrets
import hmac

# RSA-3072 public key. Only the public key is shipped with the Android app.
_RSA_N = int("d2f86d3d2c30ee512cdc5dac1ca412051f191e00993dc1f941d37c7f1ae9ccef8d7d35540f97bd8af5ea01ddbcbb92a6b9d24c53138ab1926a60af000b5909ada1c0bc3d3e9c1d15b06dbb42e05817f37fb1d0d7158515ea83c05fedf00bc612eb18a56e8e385b53783ea3b6414fcff3201f70282045701dce2a273f35779d6c07f6240c97850995c4aa81bf585e5ca22c39a09ef63e573a19438f9f6a9a2a32a9529e22cbe2720bb679b25ca743e857a020ab499b2ae9c38e5c4a7d9011469e508b174e756914c70c5232ed1fe8d8fd6489a6b253edb271401932dcc8c3c4784ad2547ea2de960d30565672a9321dc031d56cdedfdf997207e1a9cac66a2aef9762190901ae3729bfaefdd67bfc5a8b324be08fbe50e770db41b60930d95a777655e83012d527cc11052f53daa98c1d6d86d180502c5ba060be189299cde29125f08453151b3572404f2d1cc11a6f941c03119c4d5de97b474ee452a74474abab0a6c866c2133be9c3a1686ed93ab868b2fcb01e7cb9f12cbe1d7ddb52f789b", 16)
_RSA_E = 65537
_SHA256_DER_PREFIX = bytes.fromhex("3031300d060960864801650304020105000420")
_ALLOWED_ROLES = {"developer", "admin", "staff"}


def _b64u_decode(value):
    return base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))


def get_device_id(home_dir):
    path = os.path.join(home_dir, "device.id")
    if os.path.isfile(path):
        with open(path, "r", encoding="utf-8") as f:
            value = f.read().strip()
            if value:
                return value
    value = hashlib.sha256(secrets.token_bytes(32)).hexdigest()[:24].upper()
    with open(path, "w", encoding="utf-8") as f:
        f.write(value)
    return value


def verify_license(token, device_id):
    try:
        payload_part, signature_part = token.strip().split(".", 1)
        payload_bytes = _b64u_decode(payload_part)
        signature = _b64u_decode(signature_part)
        size = (_RSA_N.bit_length() + 7) // 8
        if len(signature) != size:
            return None, "License Signature चुकीची आहे."
        sig_int = int.from_bytes(signature, "big")
        decoded = pow(sig_int, _RSA_E, _RSA_N).to_bytes(size, "big")
        digest_info = _SHA256_DER_PREFIX + hashlib.sha256(payload_bytes).digest()
        padding_len = size - len(digest_info) - 3
        expected = b"\x00\x01" + (b"\xff" * padding_len) + b"\x00" + digest_info
        if padding_len < 8 or not hmac.compare_digest(decoded, expected):
            return None, "License स्वाक्षरी वैध नाही."
        data = json.loads(payload_bytes.decode("utf-8"))
        if data.get("role") not in _ALLOWED_ROLES:
            return None, "License Role चुकीचा आहे."
        if data.get("device_id") != device_id:
            return None, "हा License या डिव्हाइससाठी नाही."
        if not data.get("license_id") or not data.get("issued_at"):
            return None, "License माहिती अपूर्ण आहे."
        expires = data.get("expires_at")
        if expires:
            expiry = datetime.datetime.fromisoformat(expires.replace("Z", "+00:00"))
            now = datetime.datetime.now(datetime.timezone.utc)
            if now > expiry:
                return None, "License ची वैधता संपली आहे."
        return data, None
    except Exception:
        return None, "License Key / QR Code वाचता आला नाही."
