from flask import Flask, render_template, request, redirect, url_for, session
import qrcode, io, base64, datetime, csv, json, os, hashlib, hmac, secrets
from urllib.parse import urlencode
from license_manager import get_device_id, verify_license

app = Flask(__name__)
app.secret_key = open("secret.key", encoding="utf-8").read().strip()
CSV_FILE = "records.csv"
CONFIG_FILE = "settings.json"


def hash_password(password):
    salt = secrets.token_hex(16)
    rounds = 260000
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt), rounds).hex()
    return f"pbkdf2_sha256${rounds}${salt}${digest}"


def verify_password(password, stored):
    try:
        algorithm, rounds, salt, expected = stored.split("$", 3)
        if algorithm != "pbkdf2_sha256":
            return False
        actual = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt), int(rounds)).hex()
        return hmac.compare_digest(actual, expected)
    except Exception:
        return False


def load_settings():
    default = {
        "shop_name": "सायबर टेक्निशियन सर्व्हिसेस",
        "shop_address": "मुख्य रस्ता, महाराष्ट्र",
        "gst_no": "N/A",
        "upi_id": "yourname@upi",
        "developer_pass": "",
        "admin_pass": "",
        "staff_pass": "",
        "active_license": {},
        "active_license_token": "",
        "recovery_code_hash": ""
    }
    if not os.path.isfile(CONFIG_FILE):
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(default, f, ensure_ascii=False, indent=4)
        return default
    with open(CONFIG_FILE, "r", encoding="utf-8") as f:
        data = json.load(f)
    # Migrate legacy plaintext passwords to salted PBKDF2 hashes without losing settings.
    migrated = False
    for key in ("developer_pass", "admin_pass", "staff_pass"):
        value = data.get(key, "")
        if value and not value.startswith("pbkdf2_sha256$"):
            data[key] = hash_password(value)
            migrated = True
    if "active_license" not in data:
        data["active_license"] = {}
        migrated = True
    if "active_license_token" not in data:
        data["active_license_token"] = ""
        migrated = True
    if migrated:
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
    return data

def save_settings(data):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

def get_verified_license():
    s = load_settings()
    home = os.environ.get("HOME", os.getcwd())
    token = s.get("active_license_token", "")
    if not token:
        return None
    data, error = verify_license(token, get_device_id(home))
    return data if not error else None


@app.before_request
def enforce_signed_role():
    if request.endpoint in ("activate_license", "static"):
        return None
    license_data = get_verified_license()
    if not license_data:
        session.clear()
        return redirect(url_for("activate_license"))
    if session.get("role") and session.get("role") != license_data.get("role"):
        session.clear()
    return None

def get_next_bill_no():
    if not os.path.isfile(CSV_FILE): return "BILL-1001"
    with open(CSV_FILE, "r", encoding="utf-8") as f:
        reader = list(csv.reader(f))
        return f"BILL-{1001 + (len(reader) - 1 if len(reader) > 1 else 0)}"

@app.route("/activate", methods=["GET", "POST"])
def activate_license():
    s = load_settings()
    home = os.environ.get("HOME", os.getcwd())
    device_id = get_device_id(home)
    if get_verified_license():
        return redirect(url_for("login"))
    error = None
    if request.method == "POST":
        token = request.form.get("license_token", "").strip()
        license_data, error = verify_license(token, device_id)
        if license_data:
            s["active_license"] = license_data
            s["active_license_token"] = token
            save_settings(s)
            return redirect(url_for("first_setup"))
    return render_template("activate.html", device_id=device_id, error=error)


@app.route("/setup", methods=["GET", "POST"])
def first_setup():
    s = load_settings()
    role = (get_verified_license() or {}).get("role")
    if role not in ("developer", "admin", "staff"):
        return redirect(url_for("activate_license"))
    password_key = {"developer": "developer_pass", "admin": "admin_pass", "staff": "staff_pass"}[role]
    if s.get(password_key):
        return redirect(url_for("login"))

    if request.method == "POST":
        password = request.form.get("password", "").strip()
        confirm = request.form.get("confirm_pass", "").strip()
        recovery = request.form.get("recovery_code", "").strip()
        recovery_confirm = request.form.get("confirm_recovery_code", "").strip()
        if len(password) < 8:
            return render_template("first_setup.html", error="पासवर्ड किमान 8 अक्षरांचा असावा.", role=role)
        if password != confirm:
            return render_template("first_setup.html", error="दोन्ही पासवर्ड जुळत नाहीत.", role=role)
        if len(recovery) < 8:
            return render_template("first_setup.html", error="Recovery Code किमान 8 अक्षरांचा असावा.", role=role)
        if recovery != recovery_confirm:
            return render_template("first_setup.html", error="दोन्ही Recovery Code जुळत नाहीत.", role=role)
        s[password_key] = hash_password(password)
        s["recovery_code_hash"] = hashlib.sha256(recovery.encode()).hexdigest()
        save_settings(s)
        return redirect(url_for("login"))
    return render_template("first_setup.html", error=None, role=role)


@app.route("/", methods=["GET", "POST"])
def login():
    s = load_settings()
    license_data = s.get("active_license", {})
    role = (get_verified_license() or {}).get("role")
    if role not in ("developer", "admin", "staff"):
        return redirect(url_for("activate_license"))
    password_key = {"developer": "developer_pass", "admin": "admin_pass", "staff": "staff_pass"}[role]
    if not s.get(password_key):
        return redirect(url_for("first_setup"))
    if request.method == "POST":
        u = request.form.get("username", "").strip().lower()
        p = request.form.get("password", "").strip()
        expected_user = role
        saved_hash = s.get(password_key, "")
        if u == expected_user and verify_password(p, saved_hash):
            session.clear()
            session["user"], session["role"] = role, role
            return redirect(url_for("device_scan"))
        return render_template("step1_login.html", error="चुकीचा युजरनेम किंवा पासवर्ड!", role=role)
    return render_template("step1_login.html", role=role)


@app.route("/forgot-password", methods=["GET", "POST"])
def forgot_password():
    s = load_settings()
    error = None
    success = None

    if request.method == "POST":
        username = request.form.get("username", "").strip().lower()
        recovery = request.form.get("recovery_code", "").strip()
        password = request.form.get("new_password", "").strip()
        confirm = request.form.get("confirm_password", "").strip()

        saved_hash = s.get("recovery_code_hash", "")
        entered_hash = hashlib.sha256(recovery.encode()).hexdigest()

        if username not in ("developer", "admin", "staff") or username != (get_verified_license() or {}).get("role"):
            error = "Username चुकीचे आहे."
        elif not saved_hash or not hmac.compare_digest(entered_hash, saved_hash):
            error = "Recovery Code चुकीचा आहे."
        elif len(password) < 8:
            error = "नवीन पासवर्ड किमान 8 अक्षरांचा असावा."
        elif password != confirm:
            error = "दोन्ही पासवर्ड जुळत नाहीत."
        else:
            key = {"developer": "developer_pass", "admin": "admin_pass", "staff": "staff_pass"}[username]
            s[key] = hash_password(password)
            save_settings(s)
            success = "पासवर्ड बदलला आहे. आता Login करा."

    return render_template("forgot_password.html", error=error, success=success)

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/android-repair", methods=["GET"])
def android_repair():
    """Safe, on-device Android diagnostics and technician reference tools."""
    if "role" not in session:
        return redirect(url_for("login"))
    return render_template("android_repair.html", role=session.get("role"))


@app.route("/scan", methods=["GET", "POST"])
def device_scan():
    if "role" not in session: return redirect(url_for("login"))
    if request.method == "POST":
        # A new repair intake starts a new bill lifecycle. Clear old bill state
        # so a previous customer's bill cannot be reused accidentally.
        repair_keys = (
            "generated_bill_no", "generated_bill_total", "generated_bill_date",
            "client_name", "client_mobile", "device_info", "device_id", "received_date",
            "services", "custom_issue", "work_notes", "parts_used", "service_charge",
            "parts_charge", "gst_percent", "handover_date", "handover_name",
            "handover_mobile", "receiver_name", "receiver_mobile", "remark",
            "signature", "handover_signature", "date_str"
        )
        for key in repair_keys:
            session.pop(key, None)
        for k in ["client_name", "client_mobile", "device_info", "device_id", "received_date"]:
            session[k] = request.form.get(k, "").strip()
        return redirect(url_for("device_pair"))
    return render_template("step2_scan.html", today_iso=datetime.date.today().strftime("%Y-%m-%d"), role=session.get("role"))

@app.route("/pair", methods=["GET", "POST"])
def device_pair():
    if "role" not in session: return redirect(url_for("login"))
    if request.method == "POST": return redirect(url_for("service_page"))
    return render_template("step3_pair.html", data=session)

@app.route("/services", methods=["GET", "POST"])
def service_page():
    if "role" not in session: return redirect(url_for("login"))
    if request.method == "POST":
        srvs = request.form.getlist("services")
        session["services"] = ", ".join(srvs) if srvs else "General Service"
        session["custom_issue"] = request.form.get("custom_issue")
        return redirect(url_for("servicing"))
    return render_template("step4_services.html", data=session)

@app.route("/servicing", methods=["GET", "POST"])
def servicing():
    if "role" not in session: return redirect(url_for("login"))
    if request.method == "POST":
        session["work_notes"] = request.form.get("work_notes")
        session["parts_used"] = request.form.get("parts_used")
        try:
            service_charge = float(request.form.get("service_charge") or 0)
            parts_charge = float(request.form.get("parts_charge") or 0)
        except (TypeError, ValueError):
            return "अवैध रक्कम. कृपया योग्य आकडे टाका.", 400
        if not (0 <= service_charge <= 10000000 and 0 <= parts_charge <= 10000000):
            return "रक्कम 0 ते 1,00,00,000 दरम्यान असावी.", 400
        session["service_charge"] = service_charge
        session["parts_charge"] = parts_charge
        return redirect(url_for("service_complete"))
    return render_template("step5_servicing.html", data=session)


@app.route("/complete", methods=["GET", "POST"])
def service_complete():
    if "role" not in session:
        return redirect(url_for("login"))

    if request.method == "POST":
        try:
            gst_percent = float(request.form.get("gst_percent") or 0)
        except (TypeError, ValueError):
            return "अवैध GST टक्केवारी.", 400
        if not 0 <= gst_percent <= 100:
            return "GST टक्केवारी 0 ते 100 दरम्यान असावी.", 400
        session["gst_percent"] = gst_percent
        session["handover_date"] = request.form.get("handover_date")
        session["handover_name"] = request.form.get("handover_name", "")
        session["handover_mobile"] = request.form.get("handover_mobile", "")
        session["receiver_name"] = request.form.get("receiver_name", "")
        session["receiver_mobile"] = request.form.get("receiver_mobile", "")
        session["remark"] = request.form.get("remark")
        session["signature"] = request.form.get("signature_data", "")
        session["handover_signature"] = request.form.get("handover_signature_data", "")
        return redirect(url_for("report_page"))

    return render_template(
        "step6_complete.html",
        data=session,
        today_iso=datetime.date.today().strftime("%Y-%m-%d")
    )
@app.route("/report", methods=["GET", "POST"])
def report_page():
    if "role" not in session: return redirect(url_for("login"))
    session["date_str"] = datetime.date.today().strftime("%d-%m-%Y")
    if request.method == "POST": return redirect(url_for("bill_page"))
    return render_template("step7_report.html", data=session, shop_name=load_settings()["shop_name"])

@app.route("/bill")
def bill_page():
    if "role" not in session: return redirect(url_for("login"))
    s = load_settings()
    sc, pc, gp = session.get("service_charge", 0), session.get("parts_charge", 0), session.get("gst_percent", 0)
    sub = sc + pc
    ga = (sub * gp) / 100
    tot = sub + ga
    d_str = session.get("date_str", datetime.date.today().strftime("%d-%m-%Y"))
    c_by = session.get("user", "staff")

    rec_d = datetime.datetime.strptime(session["received_date"], "%Y-%m-%d").strftime("%d-%m-%Y") if session.get("received_date") else d_str
    hand_d = datetime.datetime.strptime(session["handover_date"], "%Y-%m-%d").strftime("%d-%m-%Y") if session.get("handover_date") else d_str

    # Reuse the bill number on refresh/back navigation; do not append a second
    # CSV row for the same repair session.
    b_no = session.get("generated_bill_no")
    if not b_no:
        b_no = get_next_bill_no()
        exists = os.path.isfile(CSV_FILE)
        with open(CSV_FILE, "a", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            if not exists:
                w.writerow(["BillNo", "Date", "Client", "Mobile", "Device", "Total", "CreatedBy"])
            w.writerow([b_no, d_str, session.get("client_name", ""), session.get("client_mobile", ""), session.get("device_info", ""), f"{tot:.2f}", c_by])
        session["generated_bill_no"] = b_no
        session["generated_bill_total"] = f"{tot:.2f}"
        session["generated_bill_date"] = d_str
    else:
        # Keep the saved amount/date stable if the bill page is refreshed.
        tot = float(session.get("generated_bill_total", f"{tot:.2f}"))
        d_str = session.get("generated_bill_date", d_str)
        sub = sc + pc
        ga = tot - sub
        gp = (ga / sub * 100) if sub else 0

    upi_params = urlencode({"pa": s.get("upi_id", ""), "pn": s.get("shop_name", ""), "am": f"{tot:.2f}", "cu": "INR"})
    qr = qrcode.make(f"upi://pay?{upi_params}")
    buf = io.BytesIO()
    qr.save(buf, format="PNG")
    qr_b64 = base64.b64encode(buf.getvalue()).decode("utf-8")

    return render_template("step8_bill.html", shop_name=s["shop_name"], shop_address=s["shop_address"], gst_no=s["gst_no"], bill_no=b_no, rec_date=rec_d, hand_date=hand_d, created_by=c_by, role=session.get("role"), data=session, service_charge=f"{sc:.2f}", parts_charge=f"{pc:.2f}", gst_percent=gp, gst_amount=f"{ga:.2f}", total=f"{tot:.2f}", qr_base64=qr_b64)

@app.route("/history")
def history():
    if session.get("role") not in ("developer", "admin"): return "<h3>⛔ फक्त Developer / Admin लाच प्रवेश आहे!</h3><a href='/scan'>परत जा</a>", 403
    recs, earn = [], 0.0
    if os.path.isfile(CSV_FILE):
        with open(CSV_FILE, "r", encoding="utf-8") as f:
            reader = list(csv.reader(f))
            for r in reader[1:]:
                if len(r) >= 6:
                    recs.append(r)
                    try: earn += float(r[5])
                    except: pass
    return render_template("history.html", records=recs[::-1], total_earning=f"{earn:.2f}")

@app.route("/settings", methods=["GET", "POST"])
def settings_page():
    if session.get("role") not in ("developer", "admin"):
        return "<h3>फक्त Developer / Admin ला प्रवेश आहे!</h3><a href='/'>Login करा</a>", 403

    s = load_settings()
    msg = ""

    if request.method == "POST":
        s["shop_name"] = request.form.get("shop_name", s["shop_name"])
        s["shop_address"] = request.form.get("shop_address", s["shop_address"])
        s["gst_no"] = request.form.get("gst_no", s["gst_no"])
        s["upi_id"] = request.form.get("upi_id", s["upi_id"])

        new_admin_pass = request.form.get("admin_pass", "").strip()
        new_staff_pass = request.form.get("staff_pass", "").strip()
        new_developer_pass = request.form.get("developer_pass", "").strip()

        password_updates = [p for p in (new_admin_pass, new_staff_pass, new_developer_pass) if p]
        if any(len(p) < 8 for p in password_updates):
            msg = "नवीन पासवर्ड किमान 8 अक्षरांचा असावा."
        elif session.get("role") == "admin" and new_developer_pass:
            msg = "Admin ला Developer पासवर्ड बदलता येत नाही."
        else:
            if new_admin_pass and session.get("role") == "developer":
                s["admin_pass"] = hash_password(new_admin_pass)
            if new_staff_pass and session.get("role") in ("developer", "admin"):
                s["staff_pass"] = hash_password(new_staff_pass)
            if new_developer_pass and session.get("role") == "developer":
                s["developer_pass"] = hash_password(new_developer_pass)

        recovery = request.form.get("recovery_code", "").strip()
        recovery_confirm = request.form.get("confirm_recovery_code", "").strip()

        if msg:
            pass
        elif recovery or recovery_confirm:
            if len(recovery) < 8:
                msg = "Recovery Code किमान 8 अक्षरांचा असावा."
            elif recovery != recovery_confirm:
                msg = "दोन्ही Recovery Code जुळत नाहीत."
            else:
                s["recovery_code_hash"] = hashlib.sha256(recovery.encode()).hexdigest()
                save_settings(s)
                msg = "Recovery Code सेव्ह झाला!"
        else:
            save_settings(s)
            msg = "सेटिंग सेव्ह झाली!"

    return render_template("settings.html", settings=s, msg=msg)
if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)


@app.route("/developer")
def developer_panel():
    if session.get("role") != "developer":
        return "<h3>फक्त Developer ला प्रवेश आहे.</h3><a href='/scan'>परत जा</a>", 403
    s = load_settings()
    return render_template("developer.html", license=s.get("active_license", {}), device_id=get_device_id(os.environ.get("HOME", os.getcwd())))
