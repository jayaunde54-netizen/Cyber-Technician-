import os
import csv
import json
import psycopg

from psycopg.rows import dict_row
from werkzeug.security import generate_password_hash, check_password_hash


DATABASE_URL = os.environ.get("DATABASE_URL")


def get_db_connection():
    if not DATABASE_URL:
        raise RuntimeError("DATABASE_URL is missing")

    return psycopg.connect(
        DATABASE_URL,
        row_factory=dict_row,
        connect_timeout=10
    )


def init_db():
    with get_db_connection() as conn:
        with conn.cursor() as cur:

            cur.execute("""
                CREATE TABLE IF NOT EXISTS settings (
                    id INTEGER PRIMARY KEY,
                    shop_name TEXT NOT NULL,
                    shop_address TEXT,
                    gst_no TEXT,
                    upi_id TEXT,
                    admin_pass TEXT,
                    staff_pass TEXT
                )
            """)

            cur.execute("""
                ALTER TABLE settings
                ADD COLUMN IF NOT EXISTS admin_pass_hash TEXT
            """)

            cur.execute("""
                ALTER TABLE settings
                ADD COLUMN IF NOT EXISTS staff_pass_hash TEXT
            """)

            cur.execute("""
                CREATE TABLE IF NOT EXISTS bills (
                    id BIGSERIAL PRIMARY KEY,
                    bill_no TEXT UNIQUE NOT NULL,
                    bill_date TEXT,
                    client_name TEXT,
                    mobile TEXT,
                    device TEXT,
                    total NUMERIC(12,2),
                    created_by TEXT
                )
            """)


def verify_login(username, password):
    with get_db_connection() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT admin_pass_hash, staff_pass_hash,
                       admin_pass, staff_pass
                FROM settings WHERE id = 1
            """)
            row = cur.fetchone()

    if not row:
        return None

    if username == "admin":
        stored = row["admin_pass_hash"]
        legacy = row["admin_pass"]

        if stored and check_password_hash(stored, password):
            return "admin"

        if not stored and legacy and password == legacy:
            return "admin"

    elif username == "staff":
        stored = row["staff_pass_hash"]
        legacy = row["staff_pass"]

        if stored and check_password_hash(stored, password):
            return "staff"

        if not stored and legacy and password == legacy:
            return "staff"

    return None


def save_passwords(admin_password=None, staff_password=None):
    with get_db_connection() as conn:
        with conn.cursor() as cur:

            if admin_password:
                cur.execute("""
                    UPDATE settings
                    SET admin_pass_hash = %s,
                        admin_pass = NULL
                    WHERE id = 1
                """, (generate_password_hash(admin_password),))

            if staff_password:
                cur.execute("""
                    UPDATE settings
                    SET staff_pass_hash = %s,
                        staff_pass = NULL
                    WHERE id = 1
                """, (generate_password_hash(staff_password),))


def add_bill(bill_no, bill_date, client_name,
             mobile, device, total, created_by):

    with get_db_connection() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                INSERT INTO bills
                (bill_no, bill_date, client_name,
                 mobile, device, total, created_by)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """, (
                bill_no, bill_date, client_name,
                mobile, device, total, created_by
            ))


def get_all_bills():
    with get_db_connection() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT bill_no, bill_date, client_name,
                       mobile, device, total, created_by
                FROM bills
                ORDER BY id DESC
            """)
            return cur.fetchall()


def get_next_bill_no():
    with get_db_connection() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT COUNT(*) AS total FROM bills
            """)
            count = cur.fetchone()["total"]

    return f"BILL-{1001 + count}"
def migrate_local_data():
    if not os.path.isfile("settings.json"):
        raise FileNotFoundError("settings.json not found")

    with open("settings.json", "r", encoding="utf-8") as f:
        settings_data = json.load(f)

    admin_password = settings_data.get("admin_pass", "")
    staff_password = settings_data.get("staff_pass", "")

    with get_db_connection() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                INSERT INTO settings (
                    id, shop_name, shop_address, gst_no, upi_id,
                    admin_pass_hash, staff_pass_hash
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (id) DO NOTHING
            """, (
                1,
                settings_data.get("shop_name", "सायबर टेक्निशियन सर्व्हिसेस"),
                settings_data.get("shop_address", ""),
                settings_data.get("gst_no", "N/A"),
                settings_data.get("upi_id", ""),
                generate_password_hash(admin_password) if admin_password else None,
                generate_password_hash(staff_password) if staff_password else None
            ))

            if os.path.isfile("records.csv"):
                with open("records.csv", "r", encoding="utf-8") as f:
                    reader = csv.DictReader(f)

                    for row in reader:
                        if not row.get("BillNo"):
                            continue

                        cur.execute("""
                            INSERT INTO bills (
                                bill_no, bill_date, client_name,
                                mobile, device, total, created_by
                            )
                            VALUES (%s, %s, %s, %s, %s, %s, %s)
                            ON CONFLICT (bill_no) DO NOTHING
                        """, (
                            row.get("BillNo"),
                            row.get("Date"),
                            row.get("Client"),
                            row.get("Mobile"),
                            row.get("Device"),
                            row.get("Total") or 0,
                            row.get("CreatedBy")
                        ))
def get_settings():
    with get_db_connection() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT shop_name, shop_address, gst_no, upi_id
                FROM settings
                WHERE id = 1
            """)
            row = cur.fetchone()

    if not row:
        raise RuntimeError("Settings database मध्ये उपलब्ध नाहीत.")

    return {
        "shop_name": row["shop_name"],
        "shop_address": row["shop_address"] or "",
        "gst_no": row["gst_no"] or "N/A",
        "upi_id": row["upi_id"] or "",
        "admin_pass": "",
        "staff_pass": ""
    }


def update_settings(data):
    with get_db_connection() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                UPDATE settings
                SET shop_name = %s,
                    shop_address = %s,
                    gst_no = %s,
                    upi_id = %s
                WHERE id = 1
            """, (
                data["shop_name"],
                data["shop_address"],
                data["gst_no"],
                data["upi_id"]
            ))
