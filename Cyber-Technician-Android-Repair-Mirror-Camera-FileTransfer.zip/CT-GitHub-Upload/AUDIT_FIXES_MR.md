# Cyber Technician – Code Audit (मराठी)

## या आवृत्तीत केलेल्या दुरुस्त्या

1. नवीन ग्राहकाची नोंद सुरू करताना मागील ग्राहकाचे bill/session fields साफ केले जातात.
2. एकाच repair session मध्ये `/bill` refresh/back केल्यास त्याच bill number चा वापर होतो; CSV मध्ये पुन्हा नोंद जोडली जात नाही.
3. Service charge आणि parts charge साठी numeric व non-negative validation जोडले.
4. GST टक्केवारीसाठी 0–100 validation जोडले.
5. UPI QR URL मधील values URL-encode केल्या.
6. Settings मधून बदलणाऱ्या पासवर्डसाठी किमान 8 अक्षरांची server-side तपासणी जोडली.

## तपासणीचे निकाल

- या प्रोजेक्टमधील 12 Python फाइल्स `py_compile` ने तपासल्या: Syntax errors नाहीत.
- `app/src/main/python/app.py` मधील सर्व `render_template()` नावांची HTML template फाइल उपलब्ध आहे.
- Android APK प्रत्यक्ष build/install/run चाचणी या वातावरणात झाली नाही. Java उपलब्ध आहे; पण system Gradle command आणि Flask/Chaquopy runtime dependencies उपलब्ध नसल्यामुळे build व runtime test प्रमाणित करता येत नाही.

## अजून करावयाच्या महत्त्वाच्या चाचण्या / सुधारणा

1. Signature data सध्या Flask cookie session मध्ये ठेवली जाते. मोठ्या signature मुळे cookie size मर्यादा ओलांडू शकते. यासाठी signature files/server-side session storage करणे योग्य.
2. CSV मधील bill number मोजणी ही single-device वापरासाठी आहे. अनेक समांतर वापरकर्ते/प्रोसेस असल्यास SQLite transaction व unique constraint वापरणे योग्य.
3. ZIP मधील root `app.py` हा वेगळा PostgreSQL backend आहे; Android APK साठी वापरला जाणारा मुख्य backend `app/src/main/python/app.py` आहे. Root backend स्वतंत्रपणे तपासून दुरुस्त करणे बाकी आहे.
4. APK build, Android lifecycle, offline storage, print/PDF आणि UPI QR प्रत्यक्ष device वर तपासणे बाकी आहे.

## APK साठी मुख्य source paths

- Python backend: `app/src/main/python/app.py`
- Android launcher: `app/src/main/java/com/cybertechnician/app/MainActivity.java`
- Manifest: `app/src/main/AndroidManifest.xml`
- Gradle module: `app/build.gradle`
