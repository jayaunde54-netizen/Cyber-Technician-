#!/usr/bin/env python3
"""Create an offline, device-bound CyberTechnician role license.
Requires OpenSSL on the computer running this tool. Keep the private PEM offline.
"""
import argparse, base64, datetime, json, pathlib, subprocess, tempfile, uuid

p = argparse.ArgumentParser(description="CyberTechnician Offline License Generator")
p.add_argument("--private-key", required=True, help="Path to your private RSA PEM (never copy into APK)")
p.add_argument("--device-id", required=True, help="Device ID shown on the app activation screen")
p.add_argument("--role", required=True, choices=["developer", "admin", "staff"])
p.add_argument("--days", type=int, default=0, help="Validity in days; 0 means no expiry")
p.add_argument("--out", default="license", help="Output filename prefix")
a = p.parse_args()

payload = {
    "license_id": str(uuid.uuid4()),
    "role": a.role,
    "device_id": a.device_id.strip().upper(),
    "issued_at": datetime.datetime.now(datetime.timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
    "expires_at": (datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(days=a.days)).replace(microsecond=0).isoformat().replace("+00:00", "Z") if a.days > 0 else None,
}
raw = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
b64 = lambda b: base64.urlsafe_b64encode(b).decode().rstrip("=")
with tempfile.NamedTemporaryFile(delete=False) as f:
    f.write(raw); payload_path = f.name
try:
    sig_path = payload_path + ".sig"
    subprocess.run(["openssl", "dgst", "-sha256", "-sign", a.private_key, "-out", sig_path, payload_path], check=True)
    token = b64(raw) + "." + b64(pathlib.Path(sig_path).read_bytes())
    pathlib.Path(a.out + ".key.txt").write_text(token, encoding="utf-8")
    try:
        import qrcode
        qrcode.make(token).save(a.out + ".png")
    except ImportError:
        print("qrcode package not installed; token text file created only")
    print("Created:", a.out + ".key.txt", "and QR image if qrcode is installed")
    print("Role:", a.role, " Device:", payload["device_id"])
finally:
    pathlib.Path(payload_path).unlink(missing_ok=True)
    pathlib.Path(payload_path + ".sig").unlink(missing_ok=True)
