from flask import Flask, render_template, request, redirect, url_for, session
import qrcode, io, base64, datetime, csv, json, os

from db import (
    init_db,
    verify_login,
    save_passwords,
    add_bill,
    get_all_bills,
    get_next_bill_no,
    get_settings,
    update_settings
)
app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY")
if not app.secret_key:
    raise RuntimeError("SECRET_KEY environment variable is missing")
CSV_FILE = "records.csv"
CONFIG_FILE = "settings.json"


def save_settings(data):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u = request.form.get("username", "").strip().lower()
        p = request.form.get("password", "").strip()

        role = verify_login(u, p)

        if role:
            session["user"], session["role"] = role, role
            return redirect(url_for("device_scan"))

        return render_template(
            "step1_login.html",
            error="चुकीचा युजरनेम किंवा पासवर्ड!"
        )

    return render_template("step1_login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/scan", methods=["GET", "POST"])
def device_scan():
    if "role" not in session: return redirect(url_for("login"))
    if request.method == "POST":
        for k in ["client_name", "client_mobile", "device_info", "device_id", "received_date"]:
            session[k] = request.form.get(k)
        return redirect(url_for("device_pair"))
    return render_template("step2_scan.html", today_iso=datetime.date.today().strftime("%Y-%m-%d"), role=session.get("role"))

@app.route("/pair", methods=["GET", "POST"])
def device_pair():
    if "role" not in session: return redirect(url_for("login"))
    if request.method == "POST": return redirect(url_for("service_page"))
    return render_template("step3_pair.html", data=session)

@app.route("/services", methods=["GET", "POST"])
def service_page():
    if "role" not in session: return redirect(url_for("login"))
    if request.method == "POST":
        srvs = request.form.getlist("services")
        session["services"] = ", ".join(srvs) if srvs else "General Service"
        session["custom_issue"] = request.form.get("custom_issue")
        return redirect(url_for("servicing"))
    return render_template("step4_services.html", data=session)

@app.route("/servicing", methods=["GET", "POST"])
def servicing():
    if "role" not in session: return redirect(url_for("login"))
    if request.method == "POST":
        session["work_notes"] = request.form.get("work_notes")
        session["parts_used"] = request.form.get("parts_used")
        session["service_charge"] = float(request.form.get("service_charge") or 0)
        session["parts_charge"] = float(request.form.get("parts_charge") or 0)
        return redirect(url_for("service_complete"))
    return render_template("step5_servicing.html", data=session)


@app.route("/complete", methods=["GET", "POST"])
def service_complete():
    if "role" not in session:
        return redirect(url_for("login"))

    if request.method == "POST":
        session["gst_percent"] = float(request.form.get("gst_percent") or 0)
        session["handover_date"] = request.form.get("handover_date")
        session["handover_name"] = request.form.get("handover_name", "")
        session["handover_mobile"] = request.form.get("handover_mobile", "")
        session["receiver_name"] = request.form.get("receiver_name", "")
        session["receiver_mobile"] = request.form.get("receiver_mobile", "")
        session["remark"] = request.form.get("remark")
        session["signature"] = request.form.get("signature_data", "")
        session["handover_signature"] = request.form.get("handover_signature_data", "")
        return redirect(url_for("report_page"))

    return render_template(
        "step6_complete.html",
        data=session,
        today_iso=datetime.date.today().strftime("%Y-%m-%d")
    )
@app.route("/report", methods=["GET", "POST"])
def report_page():
    if "role" not in session: return redirect(url_for("login"))
    session["date_str"] = datetime.date.today().strftime("%d-%m-%Y")
    if request.method == "POST": return redirect(url_for("bill_page"))
    return render_template("step7_report.html", data=session, shop_name=load_settings()["shop_name"])

@app.route("/bill")
def bill_page():
    if "role" not in session: return redirect(url_for("login"))
    s = load_settings()
    sc, pc, gp = session.get("service_charge", 0), session.get("parts_charge", 0), session.get("gst_percent", 0)
    sub = sc + pc
    ga = (sub * gp) / 100
    tot = sub + ga
    d_str = session.get("date_str", datetime.date.today().strftime("%d-%m-%Y"))
    b_no = get_next_bill_no()
    c_by = session.get("user", "staff")

    rec_d = datetime.datetime.strptime(session["received_date"], "%Y-%m-%d").strftime("%d-%m-%Y") if session.get("received_date") else d_str
    hand_d = datetime.datetime.strptime(session["handover_date"], "%Y-%m-%d").strftime("%d-%m-%Y") if session.get("handover_date") else d_str

    qr = qrcode.make(f"upi://pay?pa={s['upi_id']}&pn={s['shop_name']}&am={tot:.2f}&cu=INR")
    buf = io.BytesIO()
    qr.save(buf, format="PNG")
    qr_b64 = base64.b64encode(buf.getvalue()).decode("utf-8")
    add_bill(
        b_no,
        d_str,
        session.get("client_name", ""),
        session.get("client_mobile", ""),
        session.get("device_info", ""),
        f"{tot:.2f}",
        c_by
    )

    return render_template("step8_bill.html", shop_name=s["shop_name"], shop_address=s["shop_address"], gst_no=s["gst_no"], bill_no=b_no, rec_date=rec_d, hand_date=hand_d, created_by=c_by, role=session.get("role"), data=session, service_charge=f"{sc:.2f}", parts_charge=f"{pc:.2f}", gst_percent=gp, gst_amount=f"{ga:.2f}", total=f"{tot:.2f}", qr_base64=qr_b64)

@app.route("/history")
def history():
    if session.get("role") != "admin":
        return "<h3>⛔ फक्त Admin लाच प्रवेश आहे!</h3><a href='/scan'>परत जा</a>", 403

    rows = get_all_bills()
    recs = []
    earn = 0.0

    for row in rows:
        r = [
            row["bill_no"],
            row["bill_date"],
            row["client_name"],
            row["mobile"],
            row["device"],
            str(row["total"]),
            row["created_by"]
        ]
        recs.append(r)

        try:
            earn += float(row["total"] or 0)
        except (ValueError, TypeError):
            pass

    return render_template(
        "history.html",
        records=recs,
        total_earning=f"{earn:.2f}"
    )

@app.route("/settings", methods=["GET", "POST"])
def settings_page():
    if session.get("role") != "admin":
        return "<h3>फक्त Admin ला प्रवेश आहे!</h3><a href='/'>Login करा</a>", 403

    s = load_settings()
    msg = ""

    if request.method == "POST":
        s["shop_name"] = request.form.get("shop_name", s["shop_name"])
        s["shop_address"] = request.form.get("shop_address", s["shop_address"])
        s["gst_no"] = request.form.get("gst_no", s["gst_no"])
        s["upi_id"] = request.form.get("upi_id", s["upi_id"])

        new_admin_pass = request.form.get("admin_pass", "").strip()
        new_staff_pass = request.form.get("staff_pass", "").strip()

        save_passwords(
            admin_password=new_admin_pass or None,
            staff_password=new_staff_pass or None
        )

        save_settings(s)
        msg = "सेटिंग सेव्ह झाली!"

    return render_template("settings.html", settings=s, msg=msg)

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
