
import platform
import psutil
import shutil
import json

def get_windows_info():
    report = {}

    report["Windows Version"] = platform.platform()
    report["CPU Usage"] = str(psutil.cpu_percent(interval=1)) + "%"
    report["RAM Usage"] = str(psutil.virtual_memory().percent) + "%"

    disk = shutil.disk_usage("C:\\")
    report["Disk Total"] = round(disk.total / (1024**3), 2)
    report["Disk Used"] = round(disk.used / (1024**3), 2)
    report["Disk Free"] = round(disk.free / (1024**3), 2)

    return report

if __name__ == "__main__":
    if platform.system() != "Windows":
        print("Please run this program on Windows PC.")
    else:
        report = get_windows_info()

        print("\n===== CYBER TECHNICIAN DIAGNOSTICS =====")

        for key, value in report.items():
            print(f"{key}: {value}")

        with open("diagnostic_report.json", "w") as file:
            json.dump(report, file, indent=4)

        print("\nDiagnostic report saved successfully!")
