from fpdf import FPDF
import qrcode
import datetime
import os

# --- तुमची माहिती येथे भरा ---
SHOP_NAME = "Cyber Technicion"
SHOP_ADDRESS = "Manchar,Maharashtra"
GST_NO ="N/A"  
UPI_ID = "9272528050@ibl"     
# ----------------------------

print("--- सायबर टेक्निशियन बिल आणि रिपोर्ट जनरेटर ---")
client_name = input("ग्राहकाचे नाव (मराठी किंवा English): ")
client_mobile = input("ग्राहकाचा मोबाईल नंबर: ")
device_info = input("उपकरण / सिरीयल नंबर: ")
work_done = input("केलेल्या कामाचा तपशील: ")
service_charge = float(input("सर्व्हिस चार्ज (Rs): "))
parts_charge = float(input("पार्ट्सची किंमत (Rs): "))
gst_percent = float(input("GST टक्केवारी (नसेल तर 0 टाका): "))

subtotal = service_charge + parts_charge
gst_amount = (subtotal * gst_percent) / 100
total = subtotal + gst_amount
date_str = datetime.date.today().strftime("%d-%m-%Y")

# ऑटोमॅटिक UPI QR Code तयार करणे
upi_link = f"upi://pay?pa={UPI_ID}&pn={SHOP_NAME}&am={total:.2f}&cu=INR"
qr = qrcode.make(upi_link)
qr_file = "temp_qr.png"
qr.save(qr_file)

# PDF तयार करणे
pdf = FPDF()
pdf.add_page()

# मराठी फॉन्ट जोडणे
pdf.add_font("Marathi", "", "marathi.ttf")
pdf.set_font("Marathi", size=16)

# दुकानाचे हेडिंग
pdf.cell(0, 10, text=SHOP_NAME, new_x="LMARGIN", new_y="NEXT", align='C')
pdf.set_font("Marathi", size=10)
pdf.cell(0, 6, text=SHOP_ADDRESS, new_x="LMARGIN", new_y="NEXT", align='C')
pdf.cell(0, 6, text=f"GST No: {GST_NO}", new_x="LMARGIN", new_y="NEXT", align='C')
pdf.ln(5)
pdf.line(10, pdf.get_y(), 200, pdf.get_y())
pdf.ln(5)

# ग्राहक आणि तारीख तपशील
pdf.set_font("Marathi", size=11)
pdf.cell(0, 8, text=f"तारीख (Date): {date_str}", new_x="LMARGIN", new_y="NEXT")
pdf.cell(0, 8, text=f"ग्राहकाचे नाव: {client_name}", new_x="LMARGIN", new_y="NEXT")
pdf.cell(0, 8, text=f"मोबाईल नंबर: {client_mobile}", new_x="LMARGIN", new_y="NEXT")
pdf.cell(0, 8, text=f"उपकरण / मॉडेल: {device_info}", new_x="LMARGIN", new_y="NEXT")
pdf.ln(5)

# कामाचा रिपोर्ट
pdf.set_font("Marathi", size=12)
pdf.cell(0, 8, text="केलेल्या कामाचा रिपोर्ट (Service Report):", new_x="LMARGIN", new_y="NEXT")
pdf.set_font("Marathi", size=11)
pdf.multi_cell(0, 7, text=work_done)
pdf.ln(8)

# बिलाचा तपशील
pdf.set_font("Marathi", size=12)
pdf.cell(0, 8, text="बिलाचा तपशील (Billing Details):", new_x="LMARGIN", new_y="NEXT")
pdf.set_font("Marathi", size=11)
pdf.cell(0, 7, text=f"सर्व्हिस चार्ज: Rs. {service_charge:.2f}", new_x="LMARGIN", new_y="NEXT")
pdf.cell(0, 7, text=f"पार्ट्सची किंमत: Rs. {parts_charge:.2f}", new_x="LMARGIN", new_y="NEXT")
if gst_percent > 0:
    pdf.cell(0, 7, text=f"GST ({gst_percent}%): Rs. {gst_amount:.2f}", new_x="LMARGIN", new_y="NEXT")

pdf.ln(3)
pdf.set_font("Marathi", size=13)
pdf.cell(0, 10, text=f"एकूण रक्कम (Total Amount): Rs. {total:.2f}", new_x="LMARGIN", new_y="NEXT")

# QR Code जोडणे
pdf.ln(5)
pdf.set_font("Marathi", size=10)
pdf.cell(0, 6, text="ऑनलाईन पेमेंटसाठी खालील QR कोड स्कॅन करा:", new_x="LMARGIN", new_y="NEXT")
pdf.image(qr_file, x=15, y=pdf.get_y() + 2, w=35)

# फाईल सेव्ह करणे
safe_name = "".join(c for c in client_name if c.isalnum() or c in (' ', '_')).rstrip()
if not safe_name:
    safe_name = "Customer"
filename = f"/sdcard/Download/Bill_{safe_name.replace(' ', '_')}_{date_str}.pdf"
pdf.output(filename)

# तात्पुरती QR फाईल डिलीट करणे
if os.path.exists(qr_file):
    os.remove(qr_file)

print(f"\nयशस्वी! तुमचे मराठी बिल आणि QR कोड सेव्ह झाले आहे:\n{filename}")

