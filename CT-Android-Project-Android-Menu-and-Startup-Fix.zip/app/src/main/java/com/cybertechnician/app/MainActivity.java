package com.cybertechnician.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.widget.Toast;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;
import java.io.*;

public class MainActivity extends Activity {
  private WebView web;

  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    web = new WebView(this);
    setContentView(web);

    WebSettings settings = web.getSettings();
    settings.setJavaScriptEnabled(true);
    settings.setDomStorageEnabled(true);
    web.setWebViewClient(new WebViewClient());

    try {
      copyAssetTree("www", new File(getFilesDir(), "www"));
      if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
      Python.getInstance().getModule("server")
          .callAttr("start_server", getFilesDir().getAbsolutePath());
      web.loadUrl("http://127.0.0.1:5000/");
    } catch (Exception e) {
      Toast.makeText(this, "App सुरू करण्यात अडचण: " + e.getMessage(),
          Toast.LENGTH_LONG).show();
    }
  }

  /*
   * First try opening the asset as a file. If that fails, treat it as a
   * directory. This also replaces an old directory accidentally left at a
   * file path (for example files/www/static/logo.png).
   */
  private void copyAssetTree(String path, File dest) throws IOException {
    InputStream assetFile = null;
    try {
      assetFile = getAssets().open(path);
    } catch (IOException ignored) {
      // Not a file: process it as an asset directory below.
    }

    if (assetFile != null) {
      if (dest.exists() && dest.isDirectory()) {
        deleteRecursively(dest);
      }
      File parent = dest.getParentFile();
      if (parent != null && !parent.exists() && !parent.mkdirs()) {
        assetFile.close();
        throw new IOException("Folder तयार करता आला नाही: " + parent);
      }
      try (InputStream in = assetFile;
           OutputStream out = new FileOutputStream(dest, false)) {
        byte[] buffer = new byte[8192];
        int count;
        while ((count = in.read(buffer)) != -1) {
          out.write(buffer, 0, count);
        }
      }
      return;
    }

    if (dest.exists() && !dest.isDirectory()) {
      if (!dest.delete()) {
        throw new IOException("जुनी फाईल हटवता आली नाही: " + dest);
      }
    }
    if (!dest.exists() && !dest.mkdirs()) {
      throw new IOException("Folder तयार करता आला नाही: " + dest);
    }

    String[] children = getAssets().list(path);
    if (children == null) return;
    for (String child : children) {
      copyAssetTree(path + "/" + child, new File(dest, child));
    }
  }

  private void deleteRecursively(File file) throws IOException {
    if (file.isDirectory()) {
      File[] children = file.listFiles();
      if (children != null) {
        for (File child : children) deleteRecursively(child);
      }
    }
    if (!file.delete()) {
      throw new IOException("जुना path हटवता आला नाही: " + file);
    }
  }

  @Override public void onBackPressed() {
    if (web != null && web.canGoBack()) web.goBack();
    else super.onBackPressed();
  }
}
