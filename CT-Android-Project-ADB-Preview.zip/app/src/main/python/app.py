from flask import Flask, render_template, request, redirect, url_for, session
import qrcode, io, base64, datetime, csv, json, os

app = Flask(__name__)
app.secret_key = "temporary-key-set-by-android-server"
CSV_FILE = "records.csv"
CONFIG_FILE = "settings.json"

def load_settings():
    default = {
        "shop_name": "सायबर टेक्निशियन सर्व्हिसेस",
        "shop_address": "मुख्य रस्ता, महाराष्ट्र",
        "gst_no": "N/A",
        "upi_id": "yourname@upi",
        "admin_pass": "admin123",
        "staff_pass": "staff123"
    }
    if not os.path.isfile(CONFIG_FILE):
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(default, f, ensure_ascii=False, indent=4)
        return default
    with open(CONFIG_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def save_settings(data):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

def get_next_bill_no():
    if not os.path.isfile(CSV_FILE): return "BILL-1001"
    with open(CSV_FILE, "r", encoding="utf-8") as f:
        reader = list(csv.reader(f))
        return f"BILL-{1001 + (len(reader) - 1 if len(reader) > 1 else 0)}"

@app.route("/", methods=["GET", "POST"])
def login():
    s = load_settings()
    if request.method == "POST":
        u = request.form.get("username", "").strip().lower()
        p = request.form.get("password", "").strip()
        if u == "admin" and p == s["admin_pass"]:
            session["user"], session["role"] = "admin", "admin"
            return redirect(url_for("device_scan"))
        elif u == "staff" and p == s["staff_pass"]:
            session["user"], session["role"] = "staff", "staff"
            return redirect(url_for("device_scan"))
        return render_template("step1_login.html", error="चुकीचा युजरनेम किंवा पासवर्ड!")
    return render_template("step1_login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/scan", methods=["GET", "POST"])
def device_scan():
    if "role" not in session: return redirect(url_for("login"))
    if request.method == "POST":
        for k in ["client_name", "client_mobile", "device_info", "device_id", "received_date"]:
            session[k] = request.form.get(k)
        return redirect(url_for("device_pair"))
    return render_template("step2_scan.html", today_iso=datetime.date.today().strftime("%Y-%m-%d"), role=session.get("role"))

@app.route("/pair", methods=["GET", "POST"])
def device_pair():
    if "role" not in session: return redirect(url_for("login"))
    if request.method == "POST":
        session["adb_report"] = request.form.get("adb_report", "").strip()
        return redirect(url_for("service_page"))
    return render_template("step3_pair.html", data=session)

@app.route("/services", methods=["GET", "POST"])
def service_page():
    if "role" not in session: return redirect(url_for("login"))
    if request.method == "POST":
        srvs = request.form.getlist("services")
        session["services"] = ", ".join(srvs) if srvs else "General Service"
        session["custom_issue"] = request.form.get("custom_issue")
        return redirect(url_for("servicing"))
    return render_template("step4_services.html", data=session)

@app.route("/servicing", methods=["GET", "POST"])
def servicing():
    if "role" not in session: return redirect(url_for("login"))
    if request.method == "POST":
        session["work_notes"] = request.form.get("work_notes")
        session["parts_used"] = request.form.get("parts_used")
        session["service_charge"] = float(request.form.get("service_charge") or 0)
        session["parts_charge"] = float(request.form.get("parts_charge") or 0)
        return redirect(url_for("service_complete"))
    return render_template("step5_servicing.html", data=session)

@app.route("/complete", methods=["GET", "POST"])
def service_complete():
    if "role" not in session: return redirect(url_for("login"))
    if request.method == "POST":
        session["gst_percent"] = float(request.form.get("gst_percent") or 0)
        session["handover_date"] = request.form.get("handover_date")
        session["remark"] = request.form.get("remark")
        session["signature"] = request.form.get("signature_data")
        return redirect(url_for("report_page"))
    return render_template("step6_complete.html", data=session, today_iso=datetime.date.today().strftime("%Y-%m-%d"))

@app.route("/report", methods=["GET", "POST"])
def report_page():
    if "role" not in session: return redirect(url_for("login"))
    session["date_str"] = datetime.date.today().strftime("%d-%m-%Y")
    if request.method == "POST": return redirect(url_for("bill_page"))
    return render_template("step7_report.html", data=session, shop_name=load_settings()["shop_name"])

@app.route("/bill")
def bill_page():
    if "role" not in session: return redirect(url_for("login"))
    s = load_settings()
    sc, pc, gp = session.get("service_charge", 0), session.get("parts_charge", 0), session.get("gst_percent", 0)
    sub = sc + pc
    ga = (sub * gp) / 100
    tot = sub + ga
    d_str = session.get("date_str", datetime.date.today().strftime("%d-%m-%Y"))
    b_no = get_next_bill_no()
    c_by = session.get("user", "staff")

    rec_d = datetime.datetime.strptime(session["received_date"], "%Y-%m-%d").strftime("%d-%m-%Y") if session.get("received_date") else d_str
    hand_d = datetime.datetime.strptime(session["handover_date"], "%Y-%m-%d").strftime("%d-%m-%Y") if session.get("handover_date") else d_str

    qr = qrcode.make(f"upi://pay?pa={s['upi_id']}&pn={s['shop_name']}&am={tot:.2f}&cu=INR")
    buf = io.BytesIO()
    qr.save(buf, format="PNG")
    qr_b64 = base64.b64encode(buf.getvalue()).decode("utf-8")

    exists = os.path.isfile(CSV_FILE)
    with open(CSV_FILE, "a", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        if not exists: w.writerow(["BillNo", "Date", "Client", "Mobile", "Device", "Total", "CreatedBy"])
        w.writerow([b_no, d_str, session.get("client_name"), session.get("client_mobile"), session.get("device_info"), f"{tot:.2f}", c_by])

    return render_template("step8_bill.html", shop_name=s["shop_name"], shop_address=s["shop_address"], gst_no=s["gst_no"], bill_no=b_no, rec_date=rec_d, hand_date=hand_d, created_by=c_by, role=session.get("role"), data=session, service_charge=f"{sc:.2f}", parts_charge=f"{pc:.2f}", gst_percent=gp, gst_amount=f"{ga:.2f}", total=f"{tot:.2f}", qr_base64=qr_b64)

@app.route("/history")
def history():
    if session.get("role") != "admin": return "<h3>⛔ फक्त Admin लाच प्रवेश आहे!</h3><a href='/scan'>परत जा</a>", 403
    recs, earn = [], 0.0
    if os.path.isfile(CSV_FILE):
        with open(CSV_FILE, "r", encoding="utf-8") as f:
            reader = list(csv.reader(f))
            for r in reader[1:]:
                if len(r) >= 6:
                    recs.append(r)
                    try: earn += float(r[5])
                    except: pass
    return render_template("history.html", records=recs[::-1], total_earning=f"{earn:.2f}")

@app.route("/settings", methods=["GET", "POST"])
def settings_page():
    if session.get("role") != "admin": return "<h3>⛔ फक्त Admin लाच प्रवेश आहे!</h3><a href='/scan'>परत जा</a>", 403
    s = load_settings()
    msg = ""
    if request.method == "POST":
        for k in ["shop_name", "shop_address", "gst_no", "upi_id", "admin_pass", "staff_pass"]:
            s[k] = request.form.get(k)
        save_settings(s)
        msg = "सेटिंग्ज यशस्वीरित्या सेव्ह झाल्या! ✓"
    return render_template("settings.html", settings=s, msg=msg)

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
