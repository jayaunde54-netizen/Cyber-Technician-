package com.cybertechnician.app;

import android.content.Context;
import android.os.Build;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import io.github.muntashirakon.adb.AbsAdbConnectionManager;
import io.github.muntashirakon.adb.AdbStream;
import io.github.muntashirakon.adb.android.AdbMdns;
import java.net.InetAddress;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/** Narrow WebView bridge: pairing and read-only diagnostic commands only. */
public class AdbBridge {
    private final Context context;
    private final WebView webView;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    AdbBridge(Context context, WebView webView) {
        this.context = context.getApplicationContext();
        this.webView = webView;
    }

    @JavascriptInterface public void pairAndScan(String host, String portText, String code) {
        final String ip = host == null ? "" : host.trim();
        final String pin = code == null ? "" : code.trim();
        final int port;
        try { port = Integer.parseInt(portText); }
        catch (Exception e) { send(false, "Pairing port योग्य नाही.", ""); return; }
        if (ip.isEmpty() || port < 1 || port > 65535 || !pin.matches("[0-9]{6}")) {
            send(false, "IP Address, Pairing Port आणि 6 अंकी Pairing Code तपासा.", ""); return;
        }
        worker.execute(() -> {
            try {
                AbsAdbConnectionManager manager = AdbConnectionManager.getInstance(context);
                boolean paired = manager.pair(ip, port, pin);
                if (!paired) { send(false, "Pairing अयशस्वी. IP, Pairing Port आणि Code पुन्हा तपासा.", ""); return; }
                int connectPort = findConnectPortForIp(ip, 15000);
                if (connectPort < 1) { send(false, "Pairing झाले; पण या IP साठी ADB Connect सेवा सापडली नाही. दोन्ही फोन एकाच Wi-Fi वर ठेवा आणि Wireless Debugging सुरू ठेवा.", ""); return; }
                boolean connected = manager.connect(ip, connectPort);
                if (!connected) { send(false, "Pairing झाले; पण ADB session जोडता आले नाही. ग्राहकाच्या फोनवरील परवानगी/नेटवर्क तपासा.", ""); return; }
                String report = runReadOnlyDiagnostics(manager);
                send(true, "ग्राहकाचा फोन ADB द्वारे जोडला गेला. Read-only तपासणी पूर्ण.", report);
            } catch (Throwable t) {
                send(false, "ADB जोडताना त्रुटी: " + safeMessage(t), "");
            }
        });
    }


    private int findConnectPortForIp(String wantedIp, long timeoutMs) throws Exception {
        AtomicInteger foundPort = new AtomicInteger(-1);
        CountDownLatch latch = new CountDownLatch(1);
        AdbMdns discovery = new AdbMdns(context, AdbMdns.SERVICE_TYPE_TLS_CONNECT, (address, port) -> {
            if (address != null && wantedIp.equals(address.getHostAddress())) {
                foundPort.set(port);
                latch.countDown();
            }
        });
        discovery.start();
        try { latch.await(timeoutMs, TimeUnit.MILLISECONDS); }
        finally { discovery.stop(); }
        return foundPort.get();
    }

    private String runReadOnlyDiagnostics(AbsAdbConnectionManager manager) throws Exception {
        StringBuilder out = new StringBuilder();
        add(out, manager, "मॉडेल", "getprop ro.product.model");
        add(out, manager, "कंपनी", "getprop ro.product.manufacturer");
        add(out, manager, "Android आवृत्ती", "getprop ro.build.version.release");
        add(out, manager, "Battery माहिती", "dumpsys battery");
        add(out, manager, "Storage", "df -h /data");
        add(out, manager, "RAM माहिती", "cat /proc/meminfo");
        return out.toString();
    }

    private void add(StringBuilder out, AbsAdbConnectionManager manager, String title, String command) throws Exception {
        out.append("\n--- ").append(title).append(" ---\n");
        try (AdbStream stream = manager.openStream("shell:" + command);
             BufferedReader reader = new BufferedReader(new InputStreamReader(stream.openInputStream()))) {
            String line; int lines = 0;
            while ((line = reader.readLine()) != null && lines++ < 30) out.append(line).append('\n');
        }
    }

    @JavascriptInterface public void disconnect() {
        worker.execute(() -> {
            try { AdbConnectionManager.getInstance(context).disconnect(); send(true, "ADB कनेक्शन बंद केले.", ""); }
            catch (Throwable t) { send(false, "Disconnect त्रुटी: " + safeMessage(t), ""); }
        });
    }

    private String safeMessage(Throwable t) {
        String m = t.getMessage();
        return m == null ? t.getClass().getSimpleName() : m;
    }
    private void send(boolean ok, String message, String report) {
        try {
            JSONObject result = new JSONObject();
            result.put("ok", ok); result.put("message", message); result.put("report", report);
            final String json = result.toString();
            webView.post(() -> webView.evaluateJavascript("window.onAdbStatus && window.onAdbStatus(" + JSONObject.quote(json) + ")", null));
        } catch (Exception ignored) { }
    }
}
