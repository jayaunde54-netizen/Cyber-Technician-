package com.cybertechnician.app;

import android.app.Application;
import android.content.Context;
import android.os.Build;
import java.security.Security;
import org.conscrypt.Conscrypt;
import org.lsposed.hiddenapibypass.HiddenApiBypass;
import io.github.muntashirakon.adb.PRNGFixes;

public class CyberTechnicianApp extends Application {
    @Override public void onCreate() {
        super.onCreate();
        PRNGFixes.apply();
        if (Security.getProvider("Conscrypt") == null) {
            Security.insertProviderAt(Conscrypt.newProvider(), 1);
        }
    }

    @Override protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            HiddenApiBypass.addHiddenApiExemptions("L");
        }
    }
}
