package com.cybertechnician.app;

import android.content.Context;
import android.os.Build;
import android.sun.misc.BASE64Encoder;
import android.sun.security.provider.X509Factory;
import android.sun.security.x509.*;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.cert.Certificate;
import java.security.cert.*;
import java.security.spec.*;
import java.util.Date;
import java.util.Random;
import io.github.muntashirakon.adb.AbsAdbConnectionManager;

/** Wireless ADB identity used by Cyber-Technician. Private files stay in app storage. */
public class AdbConnectionManager extends AbsAdbConnectionManager {
    private static AbsAdbConnectionManager INSTANCE;
    private final PrivateKey privateKey;
    private final Certificate certificate;

    public static synchronized AbsAdbConnectionManager getInstance(Context context) throws Exception {
        if (INSTANCE == null) INSTANCE = new AdbConnectionManager(context.getApplicationContext());
        return INSTANCE;
    }

    private AdbConnectionManager(Context context) throws Exception {
        setApi(Build.VERSION_CODES.R); // Wireless ADB target minimum: Android 11
        PrivateKey key = readPrivateKey(context);
        Certificate cert = readCertificate(context);
        if (key == null || cert == null) {
            KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
            generator.initialize(2048, SecureRandom.getInstance("SHA1PRNG"));
            KeyPair pair = generator.generateKeyPair();
            key = pair.getPrivate();
            cert = createCertificate(pair.getPublic(), key);
            writePrivateKey(context, key);
            writeCertificate(context, cert);
        }
        privateKey = key;
        certificate = cert;
    }

    private Certificate createCertificate(PublicKey publicKey, PrivateKey privateKey) throws Exception {
        String algorithm = "SHA512withRSA";
        Date from = new Date();
        Date to = new Date(System.currentTimeMillis() + 365L * 24 * 60 * 60 * 1000);
        X500Name name = new X500Name("CN=Cyber-Technician");
        CertificateExtensions extensions = new CertificateExtensions();
        extensions.set("SubjectKeyIdentifier", new SubjectKeyIdentifierExtension(new KeyIdentifier(publicKey).getIdentifier()));
        extensions.set("PrivateKeyUsage", new PrivateKeyUsageExtension(from, to));
        X509CertInfo info = new X509CertInfo();
        info.set("version", new CertificateVersion(2));
        info.set("serialNumber", new CertificateSerialNumber(new Random().nextInt() & Integer.MAX_VALUE));
        info.set("algorithmID", new CertificateAlgorithmId(AlgorithmId.get(algorithm)));
        info.set("subject", new CertificateSubjectName(name));
        info.set("key", new CertificateX509Key(publicKey));
        info.set("validity", new CertificateValidity(from, to));
        info.set("issuer", new CertificateIssuerName(name));
        info.set("extensions", extensions);
        X509CertImpl cert = new X509CertImpl(info);
        cert.sign(privateKey, algorithm);
        return cert;
    }

    @Nullable private static PrivateKey readPrivateKey(Context c) throws Exception {
        File f = new File(c.getFilesDir(), "cyber-adb-private.key");
        if (!f.exists()) return null;
        byte[] bytes = readAll(new FileInputStream(f));
        return KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(bytes));
    }
    @Nullable private static Certificate readCertificate(Context c) throws Exception {
        File f = new File(c.getFilesDir(), "cyber-adb-cert.pem");
        if (!f.exists()) return null;
        try (InputStream in = new FileInputStream(f)) { return CertificateFactory.getInstance("X.509").generateCertificate(in); }
    }
    private static void writePrivateKey(Context c, PrivateKey key) throws IOException {
        try (OutputStream out = new FileOutputStream(new File(c.getFilesDir(), "cyber-adb-private.key"))) { out.write(key.getEncoded()); }
    }
    private static void writeCertificate(Context c, Certificate cert) throws Exception {
        try (OutputStream out = new FileOutputStream(new File(c.getFilesDir(), "cyber-adb-cert.pem"))) {
            out.write(X509Factory.BEGIN_CERT.getBytes(StandardCharsets.UTF_8)); out.write('\n');
            new BASE64Encoder().encode(cert.getEncoded(), out); out.write('\n');
            out.write(X509Factory.END_CERT.getBytes(StandardCharsets.UTF_8));
        }
    }
    private static byte[] readAll(InputStream in) throws IOException {
        try (InputStream source = in; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[4096]; int n;
            while ((n = source.read(buffer)) != -1) out.write(buffer, 0, n);
            return out.toByteArray();
        }
    }
    @NonNull @Override protected PrivateKey getPrivateKey() { return privateKey; }
    @NonNull @Override protected Certificate getCertificate() { return certificate; }
    @NonNull @Override protected String getDeviceName() { return "Cyber-Technician"; }
}
