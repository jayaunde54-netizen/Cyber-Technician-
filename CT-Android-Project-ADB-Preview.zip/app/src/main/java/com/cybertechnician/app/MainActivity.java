package com.cybertechnician.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.net.Uri;
import android.content.Intent;
import android.webkit.WebSettings;
import android.widget.Toast;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;
import java.io.*;

public class MainActivity extends Activity {
  private WebView web;
  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    web = new WebView(this); setContentView(web);
    WebSettings settings = web.getSettings(); settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true);
    web.setWebViewClient(new WebViewClient() {
      @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
        Uri uri = request.getUrl();
        if ("http".equals(uri.getScheme()) && "127.0.0.1".equals(uri.getHost()) && uri.getPort() == 5000) {
          return false;
        }
        try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) { }
        return true;
      }
    });
    web.addJavascriptInterface(new AdbBridge(this, web), "CyberADB");
    try {
      copyAssetTree("www", new File(getFilesDir(), "www"));
      if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
      Python.getInstance().getModule("server").callAttr("start_server", getFilesDir().getAbsolutePath());
      web.loadUrl("http://127.0.0.1:5000/");
    } catch (Exception e) { Toast.makeText(this, "App सुरू करण्यात अडचण: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
  }
  private void copyAssetTree(String path, File dest) throws IOException {
    dest.mkdirs(); String[] items = getAssets().list(path);
    if (items == null || items.length == 0) { try (InputStream in=getAssets().open(path); OutputStream out=new FileOutputStream(dest)) { byte[] b=new byte[8192]; int n; while((n=in.read(b))>0) out.write(b,0,n); } return; }
    for(String item:items) copyAssetTree(path + "/" + item, new File(dest,item));
  }
  @Override public void onBackPressed() { if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
