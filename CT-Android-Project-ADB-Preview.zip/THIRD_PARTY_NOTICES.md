# Third-party notices

Cyber-Technician ADB preview uses:

- **libadb-android 3.1.1** by Muntashir Al-Islam, dual-licensed under GPL-3.0-or-later or Apache-2.0. This project uses the Apache-2.0 option. Upstream: https://github.com/MuntashirAkon/libadb-android
- **sun-security-android 1.1** by Muntashir Al-Islam, used for ADB X.509 certificate generation. Upstream: https://github.com/MuntashirAkon/sun-security-android
- **Conscrypt Android 2.5.3**. Upstream: https://github.com/google/conscrypt
- **AndroidHiddenApiBypass 6.1**. Upstream: https://github.com/LSPosed/AndroidHiddenApiBypass

The upstream libadb-android project states that it has not undergone a security audit. Review all third-party licenses and security implications before distributing a production APK. See `third_party_licenses/Apache-2.0.txt` for the Apache 2.0 license text.
