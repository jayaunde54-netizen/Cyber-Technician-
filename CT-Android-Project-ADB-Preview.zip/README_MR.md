# Cyber Technician Android APK

हा Android WebView + Chaquopy प्रोजेक्ट आहे. मूळ Flask workflow आणि HTML templates जतन केले आहेत.

## GitHub Actions मधून Build
1. या ZIP मधील सर्व फाइल्स repository च्या root मध्ये upload करा.
2. GitHub मधील Actions → Build Cyber Technician APK → Run workflow निवडा.
3. पूर्ण झाल्यावर Artifacts मधून `Cyber-Technician-debug-APK` डाउनलोड करा.

## महत्त्वाच्या नोंदी
- या वातावरणात Android SDK/Gradle नेटवर्क उपलब्ध नसल्यामुळे APK प्रत्यक्ष compile करून तपासलेला नाही. GitHub Actions build हा पुढचा validation टप्पा आहे.
- पहिल्या रनला app `settings.json` तयार करेल. मूळ प्रोजेक्टमधील नमुना पासवर्ड `admin123` आणि `staff123` सार्वजनिक/कमकुवत आहेत; प्रत्यक्ष वापरापूर्वी Settings मधून दोन्ही बदला.
- हा सध्या एकाच फोनवरील स्थानिक वापरासाठी आहे; फोनवरील डेटा app storage मध्ये राहतो. App uninstall केल्यास तो डेटा नष्ट होऊ शकतो.
- QR payment फक्त UPI QR दाखवतो; पेमेंट झाल्याची खात्री किंवा स्वयंचलित reconciliation करत नाही.
- APK हा debug build आहे; Play Store साठी स्वतंत्र signed release आवश्यक आहे.


## ADB Wireless जोडणी (नवीन Preview)

- Cyber-Technician APK मध्ये embedded ADB client dependency जोडली आहे.
- Technician फोन Android 7.0+ (या प्रोजेक्टचा minSdk 24) असावा. ग्राहकाचा फोन Android 11 किंवा पुढील आवृत्तीवर असावा आणि त्यावर Wireless Debugging सुरू केलेले असावे.
- दोन्ही फोन एकाच Wi-Fi नेटवर्कवर असावेत. ग्राहकाने Pair device with pairing code स्क्रीनवरील IP, Pairing Port आणि 6 अंकी कोड द्यावा.
- जोडणीनंतर अॅप फक्त read-only diagnostics चालवते: model, manufacturer, Android version, battery, /data storage आणि RAM माहिती. कोणतीही दुरुस्ती किंवा डेटा बदल आपोआप होत नाही.
- Android 10 किंवा त्याखालील ग्राहक फोनसाठी थेट USB ADB Host Transport या Preview मध्ये जोडलेले नाही. ते वेगळे काम आहे.
- ADB ही शक्तिशाली debugging सुविधा आहे. ग्राहकाची स्पष्ट संमती घ्या आणि कामानंतर ADB कनेक्शन बंद करा तसेच ग्राहकाला Wireless Debugging बंद/Forget करण्यास सांगा.
- ADB library च्या upstream README मध्ये security audit न झाल्याची सूचना आहे. Production वापरापूर्वी security review आवश्यक आहे.
