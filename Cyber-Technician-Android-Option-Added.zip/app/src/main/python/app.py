from flask import Flask, render_template, request, redirect, url_for, session
import qrcode, io, base64, datetime, csv, json, os

app = Flask(__name__)
app.secret_key = "temporary-key-set-by-android-server"
CSV_FILE = "records.csv"
CONFIG_FILE = "settings.json"

def load_settings():
    default = {
        "shop_name": "सायबर टेक्निशियन सर्व्हिसेस",
        "shop_address": "मुख्य रस्ता, महाराष्ट्र",
        "gst_no": "N/A",
        "upi_id": "yourname@upi",
        "admin_pass": "admin123",
        "staff_pass": "staff123"
    }
    if not os.path.isfile(CONFIG_FILE):
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(default, f, ensure_ascii=False, indent=4)
        return default
    with open(CONFIG_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def save_settings(data):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

def get_next_bill_no():
    if not os.path.isfile(CSV_FILE): return "BILL-1001"
    with open(CSV_FILE, "r", encoding="utf-8") as f:
        reader = list(csv.reader(f))
        return f"BILL-{1001 + (len(reader) - 1 if len(reader) > 1 else 0)}"

@app.route("/", methods=["GET", "POST"])
def login():
    s = load_settings()
    if request.method == "POST":
        u = request.form.get("username", "").strip().lower()
        p = request.form.get("password", "").strip()
        if u == "admin" and p == s["admin_pass"]:
            session["user"], session["role"] = "admin", "admin"
            return redirect(url_for("device_scan"))
        elif u == "staff" and p == s["staff_pass"]:
            session["user"], session["role"] = "staff", "staff"
            return redirect(url_for("device_scan"))
        return render_template("step1_login.html", error="चुकीचा युजरनेम किंवा पासवर्ड!")
    return render_template("step1_login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/scan", methods=["GET", "POST"])
def device_scan():
    if "role" not in session: return redirect(url_for("login"))
    if request.method == "POST":
        for k in ["client_name", "client_mobile", "device_info", "device_id", "received_date"]:
            session[k] = request.form.get(k)
        return redirect(url_for("device_pair"))
    return render_template("step2_scan.html", today_iso=datetime.date.today().strftime("%Y-%m-%d"), role=session.get("role"))

@app.route("/pair", methods=["GET", "POST"])
def device_pair():
    if "role" not in session: return redirect(url_for("login"))
    if request.method == "POST": return redirect(url_for("service_page"))
    return render_template("step3_pair.html", data=session)

@app.route("/services", methods=["GET", "POST"])
def service_page():
    if "role" not in session: return redirect(url_for("login"))
    if request.method == "POST":
        srvs = request.form.getlist("services")
        session["services"] = ", ".join(srvs) if srvs else "General Service"
        session["custom_issue"] = request.form.get("custom_issue")
        return redirect(url_for("servicing"))
    return render_template("step4_services.html", data=session)

@app.route("/servicing", methods=["GET", "POST"])
def servicing():
    if "role" not in session: return redirect(url_for("login"))
    if request.method == "POST":
        session["work_notes"] = request.form.get("work_notes")
        session["parts_used"] = request.form.get("parts_used")
        session["service_charge"] = float(request.form.get("service_charge") or 0)
        session["parts_charge"] = float(request.form.get("parts_charge") or 0)
        return redirect(url_for("service_complete"))
    return render_template("step5_servicing.html", data=session)

@app.route("/complete", methods=["GET", "POST"])
def service_complete():
    if "role" not in session: return redirect(url_for("login"))
    if request.method == "POST":
        session["gst_percent"] = float(request.form.get("gst_percent") or 0)
        session["handover_date"] = request.form.get("handover_date")
        session["remark"] = request.form.get("remark")
        session["signature"] = request.form.get("signature_data")
        return redirect(url_for("report_page"))
    return render_template("step6_complete.html", data=session, today_iso=datetime.date.today().strftime("%Y-%m-%d"))

@app.route("/report", methods=["GET", "POST"])
def report_page():
    if "role" not in session: return redirect(url_for("login"))
    session["date_str"] = datetime.date.today().strftime("%d-%m-%Y")
    if request.method == "POST": return redirect(url_for("bill_page"))
    return render_template("step7_report.html", data=session, shop_name=load_settings()["shop_name"])

@app.route("/bill")
def bill_page():
    if "role" not in session: return redirect(url_for("login"))
    s = load_settings()
    sc, pc, gp = session.get("service_charge", 0), session.get("parts_charge", 0), session.get("gst_percent", 0)
    sub = sc + pc
    ga = (sub * gp) / 100
    tot = sub + ga
    d_str = session.get("date_str", datetime.date.today().strftime("%d-%m-%Y"))
    b_no = get_next_bill_no()
    c_by = session.get("user", "staff")

    rec_d = datetime.datetime.strptime(session["received_date"], "%Y-%m-%d").strftime("%d-%m-%Y") if session.get("received_date") else d_str
    hand_d = datetime.datetime.strptime(session["handover_date"], "%Y-%m-%d").strftime("%d-%m-%Y") if session.get("handover_date") else d_str

    qr = qrcode.make(f"upi://pay?pa={s['upi_id']}&pn={s['shop_name']}&am={tot:.2f}&cu=INR")
    buf = io.BytesIO()
    qr.save(buf, format="PNG")
    qr_b64 = base64.b64encode(buf.getvalue()).decode("utf-8")

    exists = os.path.isfile(CSV_FILE)
    with open(CSV_FILE, "a", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        if not exists: w.writerow(["BillNo", "Date", "Client", "Mobile", "Device", "Total", "CreatedBy"])
        w.writerow([b_no, d_str, session.get("client_name"), session.get("client_mobile"), session.get("device_info"), f"{tot:.2f}", c_by])

    return render_template("step8_bill.html", shop_name=s["shop_name"], shop_address=s["shop_address"], gst_no=s["gst_no"], bill_no=b_no, rec_date=rec_d, hand_date=hand_d, created_by=c_by, role=session.get("role"), data=session, service_charge=f"{sc:.2f}", parts_charge=f"{pc:.2f}", gst_percent=gp, gst_amount=f"{ga:.2f}", total=f"{tot:.2f}", qr_base64=qr_b64)

@app.route("/history")
def history():
    if session.get("role") != "admin": return "<h3>⛔ फक्त Admin लाच प्रवेश आहे!</h3><a href='/scan'>परत जा</a>", 403
    recs, earn = [], 0.0
    if os.path.isfile(CSV_FILE):
        with open(CSV_FILE, "r", encoding="utf-8") as f:
            reader = list(csv.reader(f))
            for r in reader[1:]:
                if len(r) >= 6:
                    recs.append(r)
                    try: earn += float(r[5])
                    except: pass
    return render_template("history.html", records=recs[::-1], total_earning=f"{earn:.2f}")


ANDROID_DIAGNOSTICS = {
    "wifi": {
        "title": "Wi-Fi / Internet कनेक्शन समस्या",
        "kind": "Online / Software तपासणी",
        "diagnosis": "नेटवर्क सेटिंग, राउटर, सिग्नल किंवा इंटरनेट सेवा यांपैकी कारण असू शकते.",
        "solution": "ग्राहकाच्या संमतीने Airplane mode बंद आहे का तपासा; Wi-Fi बंद/चालू करा; योग्य नेटवर्कला पुन्हा जोडून पाहा; राउटर रीस्टार्ट करा; दुसऱ्या नेटवर्कवर चाचणी करा. तरीही समस्या असल्यास नेटवर्क सेटिंग्ज तपासण्यासाठी ग्राहकाच्या फोनवर Settings उघडा.",
        "auto": "या प्रोजेक्टमध्ये ग्राहकाच्या फोनवर ADB जोडलेले नसल्याने दूरून सेटिंग बदलणे किंवा Auto-Fix चालवणे उपलब्ध नाही."
    },
    "apps": {
        "title": "App Crash / App उघडत नाही",
        "kind": "Online / Software तपासणी",
        "diagnosis": "App update, तात्पुरता cache, इंटरनेट किंवा Android compatibility कारण असू शकते.",
        "solution": "फोन रीस्टार्ट करा; Play Store मधून app update तपासा; पुरेशी मोकळी जागा ठेवा; Settings > Apps मधून संबंधित app चा cache ग्राहकाच्या संमतीने clear करा. App data clear करण्यापूर्वी डेटा हटू शकतो हे ग्राहकाला सांगा.",
        "auto": "ग्राहकाच्या फोनमध्ये ADB/अधिकृत remote session नसल्याने हा बदल अॅप स्वतः करू शकत नाही."
    },
    "slow": {
        "title": "फोन Slow / Storage Full",
        "kind": "Software तपासणी",
        "diagnosis": "मोकळी जागा कमी, अनेक background apps किंवा software update प्रलंबित असणे शक्य.",
        "solution": "Storage मध्ये किती जागा शिल्लक आहे ते ग्राहकासोबत तपासा; नको असलेल्या फाइल्सचा backup घेऊन मगच हटवा; न वापरणारे apps uninstall करा; फोन रीस्टार्ट करा आणि system update तपासा.",
        "auto": "फाइल्स किंवा app डेटा ग्राहकाच्या स्पष्ट निवडीशिवाय हटवू नका. या APK मध्ये remote cleanup उपलब्ध नाही."
    },
    "battery": {
        "title": "Battery Drain / Charging समस्या",
        "kind": "Hardware किंवा Software तपासणी",
        "diagnosis": "चार्जर/केबल, charging port, battery health किंवा background app कारण असू शकते.",
        "solution": "योग्य प्रमाणित चार्जर व केबलने तपासा; दुसऱ्या सुरक्षित चार्जरने तुलना करा; Battery usage मध्ये जास्त वापरणारे apps तपासा. चार्जिंग पोर्ट किंवा बॅटरीची समस्या कायम असल्यास प्रत्यक्ष हार्डवेअर तपासणी आवश्यक.",
        "auto": "बॅटरी किंवा charging port ची भौतिक दुरुस्ती सॉफ्टवेअरने करता येत नाही."
    },
    "display": {
        "title": "Display / Touch समस्या",
        "kind": "Hardware तपासणी",
        "diagnosis": "Screen protector, software freeze किंवा display/touch hardware कारण असू शकते.",
        "solution": "फोन रीस्टार्ट करून पाहा; स्क्रीन स्वच्छ व कोरडी ठेवा; protector मुळे touch अडतो का तपासा. समस्या कायम असल्यास display assembly व connector ची तंत्रज्ञाकडून तपासणी करा.",
        "auto": "फुटलेला/दोषपूर्ण display किंवा touch hardware ऑनलाइन दुरुस्त करता येत नाही."
    },
    "audio": {
        "title": "Speaker / Microphone समस्या",
        "kind": "Hardware किंवा Software तपासणी",
        "diagnosis": "Volume setting, Bluetooth routing, app permission किंवा audio hardware कारण असू शकते.",
        "solution": "Volume व Bluetooth तपासा; संबंधित app ला microphone permission आहे का ग्राहकाच्या संमतीने पाहा; voice recorder व speaker test करून तुलना करा. तरीही आवाज नसेल तर speaker/mic hardware तपासा.",
        "auto": "हार्डवेअर बिघाड असल्यास प्रत्यक्ष तपासणी व दुरुस्ती आवश्यक."
    }
}

@app.route("/android-diagnostics", methods=["GET", "POST"])
def android_diagnostics():
    if "role" not in session:
        return redirect(url_for("login"))
    result = None
    if request.method == "POST":
        code = request.form.get("issue", "")
        result = ANDROID_DIAGNOSTICS.get(code)
    return render_template("android_diagnostics.html", result=result)


@app.route("/settings", methods=["GET", "POST"])
def settings_page():
    if session.get("role") != "admin": return "<h3>⛔ फक्त Admin लाच प्रवेश आहे!</h3><a href='/scan'>परत जा</a>", 403
    s = load_settings()
    msg = ""
    if request.method == "POST":
        for k in ["shop_name", "shop_address", "gst_no", "upi_id", "admin_pass", "staff_pass"]:
            s[k] = request.form.get(k)
        save_settings(s)
        msg = "सेटिंग्ज यशस्वीरित्या सेव्ह झाल्या! ✓"
    return render_template("settings.html", settings=s, msg=msg)

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
