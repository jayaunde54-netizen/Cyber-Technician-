import os, threading, secrets
from app import app

_server_thread = None
def start_server(data_dir):
    global _server_thread
    os.makedirs(data_dir, exist_ok=True)
    web_dir = os.path.join(data_dir, "www")
    app.template_folder = os.path.join(web_dir, "templates")
    app.static_folder = os.path.join(web_dir, "static")
    app.config["SECRET_KEY"] = _load_secret(data_dir)
    app.secret_key = app.config["SECRET_KEY"]
    import app as app_module
    app_module.CSV_FILE = os.path.join(data_dir, "records.csv")
    app_module.CONFIG_FILE = os.path.join(data_dir, "settings.json")
    if _server_thread is None or not _server_thread.is_alive():
        _server_thread = threading.Thread(target=lambda: app.run(host="127.0.0.1", port=5000, debug=False, use_reloader=False), daemon=True)
        _server_thread.start()

def _load_secret(data_dir):
    path = os.path.join(data_dir, ".session_secret")
    if os.path.exists(path):
        return open(path, "r", encoding="utf-8").read().strip()
    value = secrets.token_urlsafe(32)
    with open(path, "w", encoding="utf-8") as f: f.write(value)
    return value
