# Cyber Technician Android APK

हा Android WebView + Chaquopy प्रोजेक्ट आहे. मूळ Flask workflow आणि HTML templates जतन केले आहेत.

## GitHub Actions मधून Build
1. या ZIP मधील सर्व फाइल्स repository च्या root मध्ये upload करा.
2. GitHub मधील Actions → Build Cyber Technician APK → Run workflow निवडा.
3. पूर्ण झाल्यावर Artifacts मधून `Cyber-Technician-debug-APK` डाउनलोड करा.

## महत्त्वाच्या नोंदी
- या वातावरणात Android SDK/Gradle नेटवर्क उपलब्ध नसल्यामुळे APK प्रत्यक्ष compile करून तपासलेला नाही. GitHub Actions build हा पुढचा validation टप्पा आहे.
- पहिल्या रनला app `settings.json` तयार करेल. मूळ प्रोजेक्टमधील नमुना पासवर्ड `admin123` आणि `staff123` सार्वजनिक/कमकुवत आहेत; प्रत्यक्ष वापरापूर्वी Settings मधून दोन्ही बदला.
- हा सध्या एकाच फोनवरील स्थानिक वापरासाठी आहे; फोनवरील डेटा app storage मध्ये राहतो. App uninstall केल्यास तो डेटा नष्ट होऊ शकतो.
- QR payment फक्त UPI QR दाखवतो; पेमेंट झाल्याची खात्री किंवा स्वयंचलित reconciliation करत नाही.
- APK हा debug build आहे; Play Store साठी स्वतंत्र signed release आवश्यक आहे.
